﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Tennisapp.Controllers
{
    [Authorize(Roles = "Admin")]
    public class Inventorycontroller : Controller
    {
        public IActionResult GetAll()
        {
            return View();
        }
    }
}

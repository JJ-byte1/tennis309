﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Tennisapp.Controllers
{
    [Authorize]
    public class eventController : Controller
    {
        public IActionResult GetAll()
        {
            return View();
        }
    }
}

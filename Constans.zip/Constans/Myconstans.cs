﻿namespace Tennisapp.Constans
{
    public enum Roles
    {
      Admin,
      user,
        User
    }
    public class Myconstans
    {
    }
}

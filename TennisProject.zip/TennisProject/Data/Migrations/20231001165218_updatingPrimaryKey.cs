﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace TennisProject.Data.Migrations
{
    /// <inheritdoc />
    public partial class updatingPrimaryKey : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using TennisProject.Models;

namespace TennisProject.Pages.Profiles
{
    public class DetailsModel : PageModel
    {
        private readonly TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context _context;

        public DetailsModel(TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context context)
        {
            _context = context;
        }

      public AspNetUser AspNetUser { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null || _context.AspNetUsers == null)
            {
                return NotFound();
            }

            var aspnetuser = await _context.AspNetUsers.FirstOrDefaultAsync(m => m.Id == id);
            if (aspnetuser == null)
            {
                return NotFound();
            }
            else 
            {
                AspNetUser = aspnetuser;
            }
            return Page();
        }
    }
}

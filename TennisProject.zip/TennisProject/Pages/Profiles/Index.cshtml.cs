﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using TennisProject.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace TennisProject.Pages.Profiles
{
 
    public class IndexModel : PageModel
    {
        private readonly TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context _context;
        private readonly UserManager<IdentityUser> _userManager;

        public IndexModel(TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context context,  UserManager<IdentityUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IList<AspNetUser> AspNetUser { get;set; } = default!;

      

        public async Task OnGetAsync()
        {
            var currentUser = await _userManager.GetUserAsync(User);

            if (currentUser != null)
            {
                // Filter the users based on the ID of the currently logged-in user
                AspNetUser = await _context.AspNetUsers
                    .Where(user => user.Id == currentUser.Id)
                    .ToListAsync();
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using TennisProject.Models;

namespace TennisProject.Pages.sub
{
    public class DetailsModel : PageModel
    {
        private readonly TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context _context;

        public DetailsModel(TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context context)
        {
            _context = context;
        }

      public Schedule Schedule { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(Guid? id)
        {
            if (id == null || _context.Schedules == null)
            {
                return NotFound();
            }

            var schedule = await _context.Schedules.FirstOrDefaultAsync(m => m.SessionId == id);
            if (schedule == null)
            {
                return NotFound();
            }
            else 
            {
                Schedule = schedule;
            }
            return Page();
        }
    }
}

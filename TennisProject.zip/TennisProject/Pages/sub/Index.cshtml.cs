﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using TennisProject.Models;

namespace TennisProject.Pages.sub
{
    public class IndexModel : PageModel
    {
        private readonly TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context _context;

        public IndexModel(TennisProject.Models.AspnetTennisProject53bc9b9d9d6a45d484292a2761773502Context context)
        {
            _context = context;
        }

        public IList<Schedule> Schedule { get;set; } = default!;

        public async Task OnGetAsync()
        {
            if (_context.Schedules != null)
            {
                Schedule = await _context.Schedules.ToListAsync();
            }
        }
    }
}
